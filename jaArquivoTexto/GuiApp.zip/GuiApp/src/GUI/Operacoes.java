/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author sdc-daniel
 */
public class Operacoes {
    
    public Operacoes(){
        
    }
    
    public Double Subtracao(Double val1, Double val2){
        
        return (val1 - val2) ;
    }
   
    public Double Divisao(Double val1, Double val2){
        
        return (val1/val2);
    }
    
    public Double Multiplicacao(Double val1, Double val2){
        
        return (val1*val2);
    }
    
    public Double Soma(Double val1, Double val2){
        
        return (val1 + val2);
    }
}
